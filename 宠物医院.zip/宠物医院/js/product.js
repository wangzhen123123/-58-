$(document).ready(function(){
    $(".case1").hover(function(){
        var _index = $(this).index();
        $(".case2").eq(_index).fadeIn();
    },function(){
        $(".case2").fadeOut();
    })
})