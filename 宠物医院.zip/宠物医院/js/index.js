var ina=document.getElementById("ab6a");
document.getElementById("toright").onclick=function(){
    scr()
}
function scr(){
    if(parseInt(ina.style.left)<=-200){
        ina.style.left="0%";
    }else{
        ina.style.left=parseInt(ina.style.left)-100+"%";
    }
}
   
setInterval(scr,10000);

document.getElementById("toleft").onclick=function(){
    if(parseInt(ina.style.left)>=0){
        ina.style.left="-200%";
    }else{
        ina.style.left=parseInt(ina.style.left)+100+"%";
    }
}
// 首页轮播图

$(document).ready(function(){
    $(".case1").hover(function(){
        var _index = $(this).index();
        $(".case2").eq(_index-1).fadeIn();
    },function(){
        $(".case2").fadeOut();
    })
})
// 划入滑出特效


var inab=document.getElementById("new2");
document.getElementById("new4").onclick=function(){
    scra()
}
function scra(){
    if(parseInt(inab.style.left)<=-100){
        inab.style.left="0%";
    }else{
        inab.style.left=parseInt(inab.style.left)-100+"%";
    }
}
   
setInterval(scr,3000);

document.getElementById("new3").onclick=function(){
    if(parseInt(inab.style.left)>=0){
        inab.style.left="-100%";
    }else{
        inab.style.left=parseInt(inab.style.left)+100+"%";
    }
}

