import { createGlobalStyle  } from 'styled-components'
export const GlobalIconStyle = createGlobalStyle`
@font-face {font-family: "iconfont";
  src: url('./iconfont.eot?t=1590045982290'); /* IE9 */
  src: url('./iconfont.eot?t=1590045982290#iefix') format('embedded-opentype'), /* IE6-IE8 */
  url('data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAAPoAAsAAAAACBwAAAOZAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHEIGVgCDMgqDPIMkATYCJAMUCwwABCAFhG0HRhsuB8gOJSHBwAB4AFBAPHwta+93/5mb690LUQUVo8/lUVsIhToF5aNCgcUpEA6PQmUh49+3aY/8rMG6sGYVd0jFCPmkxIdQ93N6WhVN6qdVPdV84n7yX4jns29zqaZKimrbAMc73w0sIq1ABhpAE+UNYzdRHsRhAs2GTYj7qIQMmCiBUYF4ELUcTExpZE1qGIS+ZGGKdzDOUN4ongB4y78fv8AtJlJ0FTjq0ZNIDYR8pT6lorqxOrm1HurGM0FbRsUhkMTTUssDFPoPIc35ndI10AyK8pX6sPiD16fUsTHgSnekbvAPj6pIQfRA8hhcS4HkK4VJKl8XkxS+epEk31PF95LcgTZS8DnwSaavPaioqlyYQSrreJzDsEKVZlx9C2/eZBAZDOFwqOrtLJuMqXubqrpmN7eEysmhjnUZjOpwfRlTypbxLG+3s4VRb98yb97kt+MH/OTN7PZydiMzjZxMziD1VFZ211Jyy/xM7jLVCdCifSQ7nhH1KlU9vyqAOXMA6g5SnbcJ4veVrKwBZ2uoovXMmVZFSC14K+Sqcng4r+aE7xxqSNWPtdoYgl4vTohvDW0tyL9+vaCgLNRLvfb6tUnImrQhnHMru3oVnq/ajXp7EYnc09uzO/co1QloD9rd27vni63ev6+wQZ6YYatd6N59ZBN54uvM4t16Lz7uveCGEP1yXcRLPHVMHW7XBSUzijC1GORQDgVZ5bs+zsS4GyfzelackkfFh/i9y1fJjxfMGVq4+vfqpeAD/Ae96xLqS4D/b9AZtClnRzfQDz7Nr9b3lwqmBfyfSCX4/C1pKa/oJ/xLKq1Fv7Ndwv8xkLoEaLu0FWolcYFA51R1Kvy5ip/oWDQ4jm0FxKYw6CIRxZR1VINNIumH6Ixcoje4QnMgevnIEgkSOY19zQLCvOMoZn1ANe8pkfQBdFZ9R28+EJpJzNpwZDtEMlzCnIw1tLqcFnmzSUB6mQxS07C22MBJSQlnsFiyii7a1cklG4rGJiyNMcVaonWTZYEWJLORjhKOwwaDmbZIZh3mZaciWbb4OTsLZU9y4s1GIN2RYBwZpkFTK0cT8cxMBNpcRuY+nwbTKmbAkWpqOtwsTGIldk5z5cSlBRGtNLWquZbuViW03MhkgjxMIDEzokWJJswA/WY0S3k/HYwnc1LUw2vhx1lqJLRVOs2vNj7jFmjAhV2UqJHRRS+fWUQTsmATKXAmrYbTidSnCOUAAAAAAA==') format('woff2'),
  url('./iconfont.woff?t=1590045982290') format('woff'),
  url('./iconfont.ttf?t=1590045982290') format('truetype'), /* chrome, firefox, opera, Safari, Android, iOS 4.2+ */
  url('./iconfont.svg?t=1590045982290#iconfont') format('svg'); /* iOS 4.1- */
}

.iconfont {
  font-family: "iconfont" !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

`
