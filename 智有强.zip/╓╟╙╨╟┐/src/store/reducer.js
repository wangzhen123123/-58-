import { combineReducers } from 'redux-immutable'
import { headerReducer } from '../common/header/store'
import { homeReducer} from '../pages/home/store'
import { detailReducer } from '../pages/detail/store'
import { loginReducer } from '../pages/login/store'
export default combineReducers({
    headerReducer,
    homeReducer,
    detailReducer,
    loginReducer
})