import styled from 'styled-components'

export const WriterWrapper = styled.div`
    width:278px;
    height:300px;
    line-height:300px;
    border: 1px solid #dcdcdc;
    text-align: center;
`