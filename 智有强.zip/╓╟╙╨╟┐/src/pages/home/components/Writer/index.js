import React, { PureComponent } from 'react'
import {
    WriterWrapper
} from './style'
export default class Writer extends PureComponent {
    render() {
        return (
            <WriterWrapper>
                WriterWrapper
            </WriterWrapper>
        )
    }
}
