import styled from 'styled-components'

export const TopicWrapper = styled.div`
    padding: 20px 0 10px 0;
    overflow: hidden;
    margin-left:-18px;
    border-bottom:1px solid #dcdcdc;
`
export const TopicItem = styled.a`
    display:block;
    float: left;
    background:#f7f7f7;
    height:32px;
    line-height: 32px;
    font-size:14px;
    color:#000;
    border: #dcdcdc 1px solid;
    border-radius:4px;
    padding-right:10px;
    margin-left:18px;
    margin-bottom:18px;
    cursor:pointer;
    .topic-pic{
        display:block;
        width:32px;
        height:32px;
        float:left;
        margin-right:10px;
    }
`

export const TopicMore = styled.a`
    display:block;
    float: left;
    background:#f7f7f7;
    height:32px;
    line-height: 32px;
    font-size:14px;
    color:#000;
    border: #dcdcdc 1px solid;
    border-radius:4px;
    padding-right:10px;
    margin-left:18px;
    margin-bottom:18px;
    cursor:pointer;
    padding-left:10px;
    &:hover{
        color: #1890ff;;
    }
`