import styled from 'styled-components'

export const ListItem = styled.div`
    padding: 20px 0;
    border-bottom:1px solid #dcdcdc;
    overflow:hidden;
    .pic{
        width:150px;
        height:100px;
        float:right;
        display:block;
        border-radius:10px;
    }
`

export const ListInfo = styled.div`
    width:458px;
    float:left;
    .title{
        line-height:28px;
        font-size:18px;
        font-weight:bold;
        color: #333333;
        margin-bottom:5px;
        .title-href{
            text-decoration:none;
            color:#333333;
        }
    }
    .desc{
        line-height:24px;
        font-size:13px;
        color:#999999;
    }
`

export const LoadMore = styled.div`
    width:100%;
    height:40px;
    margin: 30px 0;
    line-height:40px;
    background: #a5a5a5;
    text-align:center;
    border-radius:20px;
    color: #fff;
    cursor: pointer;
`