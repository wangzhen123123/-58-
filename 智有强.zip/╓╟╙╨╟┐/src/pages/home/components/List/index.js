import React, { PureComponent } from 'react'
import { connect } from 'react-redux'
import { NavLink } from 'react-router-dom'
import {
    ListItem,
    ListInfo,
    LoadMore
} from './style'
import { getMoreList } from '../../store/actionCreators'


class List extends PureComponent {
    render() {
        const { list, page } = this.props;
        return (
            <>
            {
                list.map( (item, index) => {
                    return (
                        <ListItem key={index}>
                            <img className='pic' src={item.get('imgUrl')} alt=""/>
                            <ListInfo>
                                <h3 className='title'>
                                    <NavLink className='title-href' to={'/detail/'+item.get('id')}>{item.get('title')}</NavLink>
                                </h3>
                                <p className='desc'>{item.get('desc')}</p>
                            </ListInfo>
                        </ListItem>
                    )
                })
            }
            <LoadMore onClick={this.props.getMoreList.bind(this,page)}>加载更多</LoadMore>
           </>
        )
    }
}

const mapStateToProps = state => {
    return {
        //获取数据
        list:state.getIn(['homeReducer','articleList']),
        page:state.getIn(['homeReducer','articlePage']),
    }
}
export default connect(mapStateToProps,  { getMoreList })(List)