import homeReducer from './reducer'
export { homeReducer }