import * as actionTypes from './actionTypes'
import { fromJS } from 'immutable'

const initState = fromJS({
    //专题的数据
    topicList:[],
    //List的数据
    articleList:[],
    //推荐数据
    recommendList:[],
    //article的页数
    articlePage:1,
    //返回顶部是否显示
    showScroll:false
})


export default (state = initState, action) => {
    switch(action.type){
        //页面加载完成请求home数据
        case actionTypes.GET_HOME_DATA:
            return state.merge({
                    topicList: fromJS(action.data.topicList),
                    articleList: fromJS(action.data.articleList),
                    recommendList: fromJS(action.data.recommendList)
                })
        //点击加载更多请求数据
        case actionTypes.GET_LIST_MORE:
                return state.merge({
                    articleList: state.get('articleList').concat( fromJS(action.data.articleList) ),
                    articlePage: action.nextPage
                })
        //判断返回顶部是否显示
        case actionTypes.TOGGLE_SCROLL_SHOW:
            return state.set('showScroll',action.flag)
        default:
            return state
    }
    
}