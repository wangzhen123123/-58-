import React, { PureComponent, createRef } from 'react'
import { Redirect } from 'react-router-dom'
import { connect } from 'react-redux'
import { login } from './store/actionCreators'
import {
    LoginWrapper,
    LoginBox,
    Input,
    Button
} from './style'

class Login extends PureComponent {
    constructor() {
        super()
        this.pwd = createRef()
        this.username = createRef()
    }
    render() {
        if( !this.props.loginState ){
            return (
                <LoginWrapper>
                    <LoginBox>
                        <Input placeholder='账号' ref={this.username}/>
                        <Input placeholder='密码' type='password' ref={this.pwd} />
                        <Button onClick={()=>this.props.login(this.username.current.value,this.pwd.current.value)}>登录</Button>
                   </LoginBox> 
                </LoginWrapper>
            )
        }else{
            return (
                <Redirect to='/' from='/login' exact/>
            )
        }
        
    }
}

const mapState = state => {
    return {
        loginState: state.getIn(['loginReducer','login'])
    }
}
export default connect(mapState,{ login })(Login)
