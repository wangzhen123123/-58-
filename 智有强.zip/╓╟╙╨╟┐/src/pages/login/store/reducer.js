import * as actionTypes from './actionTypes'
import { fromJS } from 'immutable'

const initState = fromJS({
    login: false
})


export default (state = initState, action) => {
    switch(action.type){
        //登入
        case actionTypes.CHANGE_LOGIN:
            return state.set('login',action.result)
        //登出
        case actionTypes.LOGINOUT:
            return state.set('login',false)
        default:
            return state
    }
    
}