export const CHANGE_LOGIN = 'CHANGE_LOGIN'
export const LOGINOUT = 'LOGINOUT'