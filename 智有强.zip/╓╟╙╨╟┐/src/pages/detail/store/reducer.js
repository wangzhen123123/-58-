import * as actionTypes from './actionTypes'
import { fromJS } from 'immutable'

const initState = fromJS({
    //detail的数据
   list:[]
})


export default (state = initState, action) => {
    switch(action.type){
      case actionTypes.GET_DETAIL_DATA:
          return state.set('list',fromJS(action.data.detailList))
        default:
            return state
    }
    
}