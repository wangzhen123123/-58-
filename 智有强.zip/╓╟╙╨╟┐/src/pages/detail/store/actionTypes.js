export const GET_DETAIL_DATA = 'GET_DETAIL_DATA'  //获取detail数据
